package com.example.usersmangmentsoftware.Service;

import com.example.usersmangmentsoftware.Repositry.userRepositry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.example.usersmangmentsoftware.Model.user;

import java.util.List;

@Service
@RequiredArgsConstructor
public class userS {

    private final userRepositry userrepositry;

    public List<user> getUser(){
     return userrepositry.findAll();
    }

    public void addUser(user u){
        userrepositry.save(u);
    }

    public boolean updateUser(Integer id , user u){
        user oldUser = userrepositry.getById(id);
        if(oldUser == null){
            return false;
        }
        oldUser.setAge(u.getAge());
        oldUser.setEmail(u.getEmail());
        oldUser.setRole(u.getRole());
        oldUser.setPassword(u.getPassword());
        oldUser.setUsername(u.getUsername());
        userrepositry.save(oldUser);
        return true;
    }

    public boolean deleteUser(Integer id){
        user User = userrepositry.getById(id);
        if(User == null){
            return false;
        }
        userrepositry.delete(User);
        return true;
    }

}
