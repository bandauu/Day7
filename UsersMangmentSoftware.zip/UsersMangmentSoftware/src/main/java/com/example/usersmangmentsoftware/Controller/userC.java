package com.example.usersmangmentsoftware.Controller;

import com.example.usersmangmentsoftware.Service.userS;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import com.example.usersmangmentsoftware.Model.user;
import com.example.usersmangmentsoftware.ApiResponse;


import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class userC {

    private final userS userService;

    @GetMapping("/get")
    public ResponseEntity getUser(){
        List<user> l = userService.getUser();
        return ResponseEntity.status(200).body(l);
    }

    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid user u){
        userService.addUser(u);
        return ResponseEntity.status(201).body(new ApiResponse("user added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateUser(@PathVariable Integer id , @RequestBody @Valid user u , Errors error){
        if(error.hasErrors()){
            String m = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(m);
        }
        boolean isUpdated = userService.updateUser(id,u);
        if(isUpdated){
            return ResponseEntity.status(200).body(new ApiResponse("user updated!"));
        }
        else
            return ResponseEntity.status(400).body(new ApiResponse("user not found!"));
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteUser(@PathVariable Integer id){
        boolean isDeleted = userService.deleteUser(id);
        if(isDeleted){
            return ResponseEntity.status(200).body(new ApiResponse("user deleted!"));
        }
        else
            return ResponseEntity.status(400).body(new ApiResponse("user not found!"));
    }

}
