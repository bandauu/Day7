package com.example.usersmangmentsoftware.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Normalized;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class user {
    @NotNull(message = "ID shouldn't be null")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer id;

    @NotEmpty(message = "name not null")
    @Size(min = 5)
    private String name;

    @NotEmpty(message = "username shouldn't be null")
    @Size(min = 5)
    @Column(columnDefinition = "unique")
    private String username;

    @NotEmpty(message = "password shouldn't be null")
    private String password;

    @NotEmpty(message = "email shouldn't be empty")
    @Pattern(regexp = "\\w+@\\w+\\.\\w")
    @Column(columnDefinition = "unique")
    private String email;

    @NotEmpty(message = "role mustn't be empty")
    @Pattern(regexp = "('user' | 'admin')")
    private String role;

    @NotNull(message = "age not null")
    private Integer age;
}




