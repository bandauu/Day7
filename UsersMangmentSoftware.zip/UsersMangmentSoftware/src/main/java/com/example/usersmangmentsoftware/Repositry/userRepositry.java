package com.example.usersmangmentsoftware.Repositry;

import com.example.usersmangmentsoftware.Model.user;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface userRepositry extends JpaRepository<user,Integer> {
}
